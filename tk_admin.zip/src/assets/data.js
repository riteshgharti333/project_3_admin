export const services = [
  {
    service_name: "Wedding Photography",
    link: "/wedding-photography",
  },
  {
    service_name: "Wedding Cinematography",
    link: "/wedding-cinematography",
  },

  {
    service_name: "Pre-Wedding Film",
    link: "/pre-wedding-film",
  },

  {
    service_name: "Pre-Wedding Photography",
    link: "/pre-wedding-photography",
  },

  {
    service_name: "Civil Marriage Photography",
    link: "/civil-marriage-photography",
  },
  {
    service_name: "Engagement Photography & Couple Portraits",
    link: "/engagement-photography-couple-portraits",
  },

  {
    service_name: "Birthday Photography",
    link: "/birthday-photography",
  },
  {
    service_name: "Baby Shower Photography",
    link: "/baby-shower-photography",
  },
  {
    service_name: "Graduation Photography",
    link: "/graduation-photography",
  },
];
//